package asint;

import asint.SintaxisAbstractaTiny.*;


public class ProcesamientoDef implements Procesamiento {
    public void procesa(Dec dec) {}
    public void procesa(Muchas_decs decs) {}
    public void procesa(Una_dec decs) {}
    public void procesa(Si_decs decs) {}
    public void procesa(No_decs decs) {}
    public void procesa(Suma exp) {}
    public void procesa(Resta exp) {}
    public void procesa(Mul exp) {}
    public void procesa(Div exp) {}

    public void procesa(Exp_lit_ent exp) {

    }

    public void procesa(Exp_lit_real exp) {

    }


    public void procesa(Lit_ent exp) {}
    public void procesa(Lit_real exp) {}

    public void procesa(Lit_bool t) {

    }

    public void procesa(Lit_string exp) {

    }

    public void procesa(Iden exp) {}

    public void procesa(Array t) {

    }

    public void procesa(Prog prog) {}

    public void procesa(Puntero t) {

    }

    public void procesa(Struct t) {

    }

    public void procesa(PFref pform) {

    }

    public void procesa(PFnoref pform) {

    }

    public void procesa(Pform pform) {

    }

    public void procesa(PFormOpt pforms) {

    }

    public void procesa(Si_pforms pforms) {

    }

    public void procesa(No_pforms pforms) {

    }

    public void procesa(Muchos_pforms pforms) {

    }

    public void procesa(Un_pform pform) {

    }

    public void procesa(Dec_var dec) {

    }

    public void procesa(Dec_tipo dec) {

    }

    public void procesa(Dec_proc dec) {

    }

    public void procesa(Bloque bloque) {

    }

    public void procesa(Camp campo) {

    }

    public void procesa(Muchos_camp camps) {

    }

    public void procesa(Un_camp camp) {

    }

    public void procesa(Ins_asig ins) {

    }

    public void procesa(Ins_read ins) {

    }

    public void procesa(Ins_write ins) {

    }

    public void procesa(Ins_new ins) {

    }

    public void procesa(Ins_delete ins) {

    }

    public void procesa(Ins_nl ins) {

    }

    public void procesa(Ins_if ins) {

    }

    public void procesa(Ins_if_else ins) {

    }

    public void procesa(Ins_while ins) {

    }

    public void procesa(Ins_call ins) {

    }

    public void procesa(Ins_bloque ins) {

    }

    public void procesa(Una_ins ins) {

    }

    public void procesa(Muchas_ins ins) {

    }

    public void procesa(Si_preal lpreal) {

    }

    public void procesa(No_preal lpreal) {

    }

    public void procesa(Muchos_preal lpreal) {

    }

    public void procesa(Un_PReal exp) {

    }

    public void procesa(Exp_Iden exp) {

    }

    public void procesa(Exp_lit_cadena exp) {

    }

    public void procesa(Exp_lit_BoolTrue exp) {

    }

    public void procesa(Exp_lit_BoolFalse exp) {

    }


    public void procesa(Exp_null exp) {

    }

    public void procesa(AccesoArray exp) {

    }

    public void procesa(AccesoPuntero exp) {

    }

    public void procesa(AccesoCampo exp) {

    }

    public void procesa(And exp) {

    }

    public void procesa(Or exp) {

    }

    public void procesa(SintaxisAbstractaTiny.Mod exp) {}
    public void procesa(SintaxisAbstractaTiny.Asig exp) {}

    public void procesa(SintaxisAbstractaTiny.Mayor exp) {}

    public void procesa(SintaxisAbstractaTiny.Menor exp) {}
    public void procesa(SintaxisAbstractaTiny.MayorIg exp) {}

    public void procesa(SintaxisAbstractaTiny.MenorIg exp) {}

    public void procesa(SintaxisAbstractaTiny.Igual exp) {}

    public void procesa(SintaxisAbstractaTiny.Desigual exp) {}

    public void procesa(SintaxisAbstractaTiny.Neg exp) {}

    public void procesa(SintaxisAbstractaTiny.Not exp) { }


}
